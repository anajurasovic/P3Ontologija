<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Jurasovic\Ontologija;
use Composer\Autoload\ClassLoader;

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Jurasovic\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /nominacije_baza', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('http://oziz.ffos.hr/nastava20192020/ajurasovic_19/ontologija/nominacije_jurasovic.rdf');

    foreach ($foaf->resources() as $resource) {

      $film = $foaf->get($resource, '<http://oziz.ffos.hr/ajurasovic/fn-ontologija#glumiU>');

      if($film != ''){

      $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/ajurasovic/nominacije#uri_glumca>'));
      $glumac = str_replace('_', ' ', $url["fragment"]);
      $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/ajurasovic/nominacije#uri_nagrade>'));
      $nagrada = str_replace('_', ' ', $url["fragment"]);
      $mjesto = "".$foaf->get($resource, '<http://oziz.ffos.hr/ajurasovic/fn-ontologija#jeUDrzavi>');
      $godina = "".$foaf->get($resource, '<http://oziz.ffos.hr/ajurasovic/fn-ontologija#Godina_osvajanja>');
      $dobioNagradu = "".$foaf->get($resource, '<http://oziz.ffos.hr/ajurasovic/fn-ontologija#Dobio_nagradu>');


        $ontologija = new Ontologija();
        $ontologija->setPodaci(Flight::request()->data);

        $ontologija->setGlumac($glumac);
        $ontologija->setFilm($film);
        $ontologija->setNagrada($nagrada);
        $ontologija->setMjesto($mjesto);
        $ontologija->setGodina($godina);
        $ontologija->setDobioNagradu($dobioNagradu);

        $doctrineBootstrap = Flight::entityManager();
        $em = $doctrineBootstrap->getEntityManager();

        $em->persist($ontologija);
        $em->flush();
    }
  }

  echo "Uspješno!";
});

Flight::route('GET /search/@glumac', function($glumac){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Jurasovic\Ontologija');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.glumac LIKE :glumac')
                        ->setParameter('glumac', '%'.$glumac.'%')
                        ->getQuery()
                        ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

Flight::route('GET /search/@film', function($film){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Jurasovic\Ontologija');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.film LIKE :film')
                        ->setParameter('film', '%'.$film.'%')
                        ->getQuery()
                        ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Jurasovic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();
