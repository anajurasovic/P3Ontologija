create database ajurasovic_19 default character set utf8;
use ajurasovic_19;
create table nominacije(
    sifra int not null primary key auto_increment,
    glumac varchar(255) not null,
    film varchar(255) not null,
    nagrada varchar(255) not null,
    mjesto varchar(255) not null,
    godina int not null,
    dobioNagradu varchar(10) not null
);
