<?php

namespace Jurasovic;

/**
 * @Entity @Table(name="nominacije")
 **/


class Ontologija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $glumac;

    /**
    * @Column(type="string")
    */
    private $film;
    
    /**
    * @Column(type="string")
    */
    private $nagrada;

    /**
    * @Column(type="string")
    */
    private $mjesto;

    /**
    * @Column(type="integer")
    */
    private $godina;

    /**
    * @Column(type="string")
    */
    private $dobioNagradu;

  public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

  public function getFilm(){
		return $this->film;
	}

	public function setFilm($film){
		$this->film = $film;
	}

  public function getGlumac(){
    return $this->glumac;
  }

  public function setGlumac($glumac){
		$this->glumac = $glumac;
	}

  public function getMjesto(){
  	return $this->mjesto;
  }

  public function setMjesto($mjesto){
		$this->mjesto = $mjesto;
	}

  public function getNagrada(){
    return $this->nagrada;
  }

  public function setNagrada($nagrada){
    $this->nagrada = $nagrada;
  }

  public function getDobioNagradu(){
    return $this->dobioNagradu;
  }

  public function setDobioNagradu($dobioNagradu){
    $this->dobioNagradu = $dobioNagradu;
  }

  public function getGodina(){
    return $this->godina;
  }

  public function setGodina($godina){
    $this->godina = $godina;
  }

  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}
?>
